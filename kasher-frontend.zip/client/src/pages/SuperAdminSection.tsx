/* Kasher — SuperAdmin workspace. This shell never fabricates platform data; each unavailable section names the missing backend contract. */
import { ArrowRight, Bell, FileCheck2, PackageSearch, Send, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

const sections: Record<string, { title: string; description: string; icon: typeof Users; endpoint: string }> = {
  traders: { title: "التجار والأدمنز", description: "إدارة حسابات أصحاب المتاجر وصلاحياتهم على المنصة.", icon: Users, endpoint: "مسار إدارة التجار غير موثق في الباك إند الحالي" },
  subscriptions: { title: "الاشتراكات", description: "مراجعة طلبات الاشتراك واعتمادها أو رفضها.", icon: FileCheck2, endpoint: "مسار الاشتراكات غير موثق في الباك إند الحالي" },
  products: { title: "منتجات المنصة", description: "عرض المنتجات عبر جميع التجار مع التصفية حسب التاجر.", icon: PackageSearch, endpoint: "مسار منتجات المنصة غير موثق في الباك إند الحالي" },
  invoices: { title: "فواتير المنصة", description: "متابعة حركة الفواتير على مستوى النظام بالكامل.", icon: FileCheck2, endpoint: "مسار فواتير المنصة غير موثق في الباك إند الحالي" },
  notifications: { title: "الإشعارات", description: "إرسال رسائل تشغيلية إلى مجموعة من المستخدمين.", icon: Bell, endpoint: "مسار الإشعارات غير موثق في الباك إند الحالي" },
};

function UnavailablePanel({ section }: { section: keyof typeof sections }) {
  const item = sections[section];
  const Icon = item.icon;
  return <div className="rounded-2xl border border-[#ead8ca] bg-[#fffdfa] p-6"><div className="flex items-start gap-4"><div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#f5e7df] text-[#b96f4a]"><Icon size={20} aria-hidden="true" /></div><div><h2 className="font-display text-lg font-bold">لا توجد بيانات تشغيلية بعد</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-[#77736f]">لم يتم عرض أرقام أو سجلات تجريبية حتى لا تختلط بيانات المنصة الحقيقية ببيانات وهمية.</p><p className="mt-3 rounded-xl bg-[#faf7f1] p-3 text-xs font-semibold text-[#9b6245]">{item.endpoint}</p></div></div></div>;
}

export default function SuperAdminSection({ section }: { section: string }) {
  const [, navigate] = useLocation();
  const current = sections[section] || sections.traders;
  const Icon = current.icon;
  const go = (key: string) => navigate(key === "overview" ? "/super-admin" : `/super-admin/${key}`);
  return <div dir="rtl" className="min-h-screen bg-[#f7f4ee] text-[#172433]"><aside className="fixed inset-y-0 right-0 z-30 hidden w-[270px] border-l border-[#e7e0d4] bg-[#fbfaf7] px-5 py-6 lg:block"><div className="mb-10 flex items-center gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#172433]"><img src="/manus-storage/kasher-mark_178c0f71.png" alt="Kasher" className="h-7 w-7" /></div><div><b className="font-display text-xl">Kasher</b><p className="text-[10px] text-[#8a8378]">إدارة النظام</p></div></div><p className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[.18em] text-[#a39b90]">نطاق المنصة</p><nav className="space-y-1"><button onClick={() => go("overview")} className="mb-2 flex w-full items-center gap-3 rounded-xl px-3 py-3 text-right text-sm text-[#6f6b65] hover:bg-[#f0ebe3]"><ArrowRight size={17} aria-hidden="true" /> نظرة عامة</button>{Object.entries(sections).map(([key, item]) => { const NavIcon = item.icon; return <button key={key} onClick={() => go(key)} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-right text-sm transition ${key === section ? "bg-[#172433] font-semibold text-white" : "text-[#6f6b65] hover:bg-[#f0ebe3]"}`}><NavIcon size={17} aria-hidden="true" /><span>{item.title}</span>{key === section && <i className="mr-auto h-1.5 w-1.5 rounded-full bg-[#d99a78]" />}</button>; })}</nav></aside><header className="flex h-[76px] items-center justify-between border-b border-[#e9e3d9] bg-[#fbfaf7] px-5 md:px-9 lg:mr-[270px]"><button onClick={() => go("overview")} className="flex items-center gap-3 text-sm font-bold"><ArrowRight size={16} aria-hidden="true" /><span className="font-display text-xl">{current.title}</span></button><Button variant="outline" onClick={() => go("overview")} className="gap-2 rounded-xl border-[#ded5c9] bg-transparent"><ArrowRight size={16} aria-hidden="true" /> لوحة النظام</Button></header><main className="mx-auto max-w-[1200px] px-5 py-9 md:px-9 md:py-12 lg:mr-[270px]"><div className="mb-9 flex flex-col justify-between gap-5 md:flex-row md:items-end"><div><p className="mb-3 text-xs font-bold text-[#637c5d]">إدارة المنصة</p><h1 className="font-display text-3xl font-bold tracking-[-.04em]">{current.title}</h1><p className="mt-2 text-sm text-[#898278]">{current.description}</p></div><Button disabled className="gap-2 rounded-xl bg-[#172433] opacity-60"><Icon size={16} aria-hidden="true" /> لا يوجد مسار API</Button></div><div className="mb-7 flex flex-wrap gap-2">{Object.entries(sections).map(([key, item]) => <button key={key} onClick={() => go(key)} className={`rounded-xl px-4 py-2.5 text-xs font-bold transition ${key === section ? "bg-[#172433] text-white" : "border border-[#e4dcd1] bg-[#fffdfa] text-[#7b756c] hover:bg-white"}`}>{item.title}</button>)}</div><UnavailablePanel section={(sections[section] ? section : "traders") as keyof typeof sections} /></main></div>;
}

export function SuperAdminUnavailableNote() {
  return <p className="flex items-center gap-2 text-xs text-[#999187]"><Send size={14} aria-hidden="true" /> يتم تفعيل هذا القسم بعد توثيق عقد SuperAdmin في الباك إند.</p>;
}
